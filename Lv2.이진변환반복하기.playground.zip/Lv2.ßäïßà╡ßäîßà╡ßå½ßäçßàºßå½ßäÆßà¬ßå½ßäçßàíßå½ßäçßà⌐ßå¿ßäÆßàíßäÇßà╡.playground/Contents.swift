import Foundation


var num = Int(String(String(45, radix:2)))!
print(String(45,radix: 2)


//var name = "swift"
//var aa = name.enumerated()
//var a = [Int : Character]()
//for (index, number) in name.enumerated() {
//    append.a(index, number))
//}
//
//let numbers1 = "123456"
//var str = Array(numbers1)
//print(str)
//var str2 = Array(numbers1).map{ String($0) }
//print(str2)
//
//let arr1 = Array(repeating: Array(repeating: 0, count: 3), count: 5)
//print(arr1)
//
//var a = ["tank", "kick", "know", "wheel", "land", "dream", "mother", "robot", "tank"]
//var b = a.last!.first!
//var counter = [String: Int]()
//var x = print(a.forEach { counter [$0, default: 0] += 1 })
//print(x)

//func solution(_ s: String) -> [Int] {
//    var count = 0
//    var sum = 0
//    var arrayS = Array(s)
//
//    while arrayS != ["1"] {
//        var number = 0
//        count += 1
//        number = arrayS.filter { $0 == "1" }.count
//        sum += arrayS.filter { $0 == "0" }.count
//        arrayS = Array(String(number, radix: 2))
//    }
//    return [count,sum]
//}
//solution("110010101001")
//
